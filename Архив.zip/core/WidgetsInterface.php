<?php
namespace core;

interface WidgetsInterface
{



    public static function run($params);
}